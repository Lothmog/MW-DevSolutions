## Project Description

* [live example](https://learning-zone.github.io/website-templates/sb-admin-2)

![alt text](https://github.com/learning-zone/website-templates/blob/master/assets/sb-admin-2.png "sb-admin-2")
